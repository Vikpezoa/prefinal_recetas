from recetas_app import app
from recetas_app.controladores import controlador_usuarios, controlador_recetas
#from login_registro_app.controladores import controlador_usuarios CREO CONTROLADOR Y LO IMPORTO AUTOMATICAMENTE EN SERVER (MODIFICAR DE SER NECESARIO)

if __name__ == "__main__":
    app.run(debug = True, port = 5001 )

