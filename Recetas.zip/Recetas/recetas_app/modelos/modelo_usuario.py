from recetas_app.config.mysqlconnection import connectToMySQL
from recetas_app import BASE_DATOS, EMAIL_REGEX, NOMBRE_REGEX
from flask import flash

class Usuario:
    def __init__(self,data):
        self.id = data['id']
        self. nombre = data['nombre']
        self.apellido = data['apellido']
        self.password = data['password']
        self.fecha_creacion = data ['fecha_creacion']
        self.fecha_actualizacion = data ['fecha_actualizacion']
        self.email = data['email']

    #class method para login:
    @classmethod
    def obtener_uno_con_email(cls, data):
        query= """
                SELECT * FROM usuarios 
                WHERE email = %(email)s
                """
        resultado = connectToMySQL(BASE_DATOS).query_db(query,data)
        if len(resultado)==0:
            return None
        else:
            return Usuario (resultado[0])
    
    @classmethod
    def crear_uno(cls,data):
        query= """
                INSERT INTO usuarios (nombre, apellido, email, password)
                VALUES (%(nombre)s, %(apellido)s, %(email)s, %(password)s);
                """
        id_usuario = connectToMySQL(BASE_DATOS).query_db(query,data) #?????? la vez pasada puso resultado
        return id_usuario


    @staticmethod
    def validar_registro(data, usuario_existe):
        es_valido =True
        if len(data['nombre'])<2:
            es_valido = False
            flash("Por favor inserte un nombre. Al menos contiene 3 caracteres.","error_nombre")
        if len(data['apellido'])<2:
            es_valido = False
            flash("Por favor inserte un nombre. Al menos contiene 3 caracteres.","error_apellido")

        if not NOMBRE_REGEX.match(data['nombre']):
            es_valido = False
            flash("Por favor proporciona un nombre válido (Solo letras).","error_nombre")
        
        if len(data['apellido'])<2:
            es_valido = False
            flash("Por favor inserte un apellido. Al menos cotiene 3 caracteres.","error_apellido")
            
        if not NOMBRE_REGEX.match(data['apellido']):
            es_valido = False
            flash("Por favor proporciona un apellido válido (Solo letras).","error_apellido")

        if not EMAIL_REGEX.match(data['email']):
            es_valido = False
            flash("Por favor proporciona un email válido","error_email")
        
        if len(data['password'])<8:
            es_valido = False
            flash("Tu contraseña debe tener al menos 8 caracteres","error_password")
        
        if data ['password']!= data['confirmacion_password']:
            es_valido = False
            flash("Tu contraseña no coincide","error_password")

        if usuario_existe != None:
            es_valido = False
            flash(" Este correo ya esta en uso, por favor ingresar otro","error_email")
        return es_valido
    