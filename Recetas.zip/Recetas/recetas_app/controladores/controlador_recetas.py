from flask import Flask, render_template, request, session, redirect
from recetas_app import app
from recetas_app.modelos.modelo_recetas import Receta

@app.route('/recetas')
def desplegar_recetas():
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        lista_recetas = Receta.obtener_todas_con_usuario()
        #Obtener todas las recetas
        #Enviar la lista de recetas hacia el template
        return render_template('recetas.html', lista_recetas=lista_recetas)
#necesitamos en el html importar una tabla para mostrarlas mediante ciclo

@app.route( '/formulario/receta')
def desplegar_formulario_receta():
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        return render_template( 'formulario_receta.html' )

@app.route( '/crear/receta', methods = ['POST'] )
def nueva_receta():
    data = {
        **request.form,
        "id_usuario" : session['id_usuario']
    }
    if Receta.validar_formulario_recetas( data ) == False:
        return redirect( '/formulario/receta' )
    else:
        id_receta = Receta.crear_uno( data )
        return redirect( '/recetas' ) 
    
    #UTIL PARA VER SI LLEGA LA DATA: print(request.form) ->luego de completar los casilleros del sitio.

@app.route('/eliminar/receta/<int:id>', methods=['POST'])
def eliminar_receta(id):
    data={
        "id":id
    }
    Receta.elimina_uno(data)
    return redirect('/recetas')

@app.route('/receta/<int:id>')
def desplegar_receta(id):
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        data={
            "id":id
        }
        receta=Receta.obtener_uno_con_usuario(data)
        return render_template('receta.html',receta=receta)

@app.route('/formulario/editar/receta/<int:id>')
def desplegar_editar_receta(id):
    if "id_usuario" not in session:
        return redirect( '/' )
    else:
        data = {
            "id" : id
        }
        receta=Receta.obtener_uno(data) #OBTENER UNO CON USUARIO NO, OBTENER UNO, PUESTO QUE SOLO SE PUEDE EDITAR CON EL MISMO USUARIO, NO CON CUALQUIERA.
        return render_template('editar_receta.html',receta=receta)

@app.route('/editar/receta/<int:id>',methods=['POST'])
def editar_receta( id ):
    if Receta.validar_formulario_recetas( request.form ) == False:
        return redirect( f'/formulario/editar/receta/{id}' )
    else:
        data = {
            **request.form,
            "id" : id
        }
        Receta.editar_uno( data )
        return redirect( '/recetas' )
    




